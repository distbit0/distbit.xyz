Zcash Q3 2026 grant-market cutoff audit

Evidence captured 2026-10-14; publication packaged 2026-10-23.
All 37 markets are retained. Blank original_gpt_forecast cells in markets.csv
mean unavailable, not zero. Quotes are raw collateral-denominated prices.
The October 14 website snapshot includes trades after the announced cutoff.

From the extracted directory, verify the captured evidence offline:

python 2026-10-14/zcash-audit/audit.py verify 2026-10-14/zcash-audit/evidence --snapshot 2026-10-14/zcash-audit/snapshot

Run the three checks against the actual captures:

python -m unittest discover -s 2026-10-14/zcash-audit/tests -v

Python 3.10+ standard library only. These verification commands do not access
the network. The capture subcommands are preserved source code, not part of
this standalone offline package's supported workflow.

The JSON report contains the complete market-by-market joins and both scores.
Each evidence manifest records public source URLs, retrieval dates and hashes.
Hashes check file consistency, not the correctness of the original providers.
The audit relies on one Optimism RPC provider and published finalized vote
tallies, not an independently operated node or a recount of encrypted ballots.
Original GPT forecasts are absent, so trader improvement over GPT is unmeasured.

Source article: https://distbit.xyz/zcash-grant-forecast-cutoff/
