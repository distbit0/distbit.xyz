#!/usr/bin/env python3
"""Capture and verify the Q3 Zcash pilot's Uniswap v3 activity. Public reads only."""

import argparse
import hashlib
import json
import sys
import time
import urllib.error
import urllib.request
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from decimal import Decimal, localcontext
from pathlib import Path


RPC_URL = "https://mainnet.optimism.io"
FACTORY = "0x1f98431c8ad98523631ae4a59f267346ea31f984"
# First block at or after 2026-08-18 00:00 UTC, found by timestamp binary search.
START_BLOCK = 155706212
START_TIME = 1787011200
CREATED = "0x783cca1c0412dd0d695e784568c96da2e9c22ff989357a2e8b1d9b2b4e6b7118"
TOPICS = {
    "initialize": "0x98636036cb66a9c19a37435efc1e90142190214e8abeb821bdba3f2990dd4c95",
    "swap": "0xc42079f94a6350d7e6235f29174924f928cc2ac818eb64fed8004e115fbcca67",
    "mint": "0x7a53080ba414158be7ec69b987b5fb7d07dee101fe85488f0853ae16239d0bde",
    "burn": "0x0c396cd989a39f4459b5fa1aed6a9a8dcdbc45908acfd67e028cd568da98982c",
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def rpc(method, params):
    request = urllib.request.Request(
        RPC_URL,
        data=json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params}).encode(),
        headers={"Content-Type": "application/json"},
    )
    for attempt in range(5):
        try:
            with urllib.request.urlopen(request, timeout=45) as response:
                result = json.load(response)
            break
        except urllib.error.HTTPError as error:
            if error.code not in (429, 500, 502, 503, 504) or attempt == 4:
                raise
            delay = 2 ** (attempt + 1)
            print(f"RPC {method}: HTTP {error.code}; retry in {delay}s", file=sys.stderr, flush=True)
            time.sleep(delay)
    require("error" not in result, f"RPC {method} failed: {result.get('error')}")
    require(result.get("result") is not None, f"RPC {method} returned no result")
    return result["result"]


def parallel_map(function, items):
    # The public endpoint returned HTTP 429 at 20 concurrent requests.
    with ThreadPoolExecutor(max_workers=4) as executor:
        return list(executor.map(function, items))


def words(encoded):
    require(encoded.startswith("0x") and (len(encoded) - 2) % 64 == 0, "Malformed ABI words")
    return [int(encoded[offset:offset + 64], 16) for offset in range(2, len(encoded), 64)]


def signed(value, bits=256):
    return value - (1 << bits) if value >= 1 << (bits - 1) else value


def event_key(event):
    return (int(event["blockNumber"], 16), int(event["transactionIndex"], 16), int(event["logIndex"], 16))


def timestamp(block):
    return datetime.fromtimestamp(int(block["timestamp"], 16), timezone.utc).isoformat()


def read_events(filters, end_block, start_block=START_BLOCK):
    spans = [(start, min(start + 9999, end_block))
             for start in range(start_block, end_block + 1, 10000)]

    def fetch(span):
        return rpc("eth_getLogs", [{**filters, "fromBlock": hex(span[0]), "toBlock": hex(span[1])}])

    events = [event for group in parallel_map(fetch, spans) for event in group]
    require(len({event_key(event) for event in events}) == len(events), "Duplicate event")
    require(all(not event["removed"] for event in events), "Removed event in finalized interval")
    return sorted(events, key=event_key)


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def select_cutoff(finalized, before):
    if before is None:
        return finalized
    boundary = datetime.fromisoformat(before)
    require(boundary.tzinfo is not None and boundary.microsecond == 0,
            "--before requires an explicit timezone and whole seconds")
    target = int(boundary.timestamp())
    require(START_TIME < target <= int(finalized["timestamp"], 16),
            "Requested cutoff must follow the start date and already be finalized")
    lower, upper = START_BLOCK - 1, int(finalized["number"], 16) + 1
    while lower + 1 < upper:
        middle = (lower + upper) // 2
        candidate = rpc("eth_getBlockByNumber", [hex(middle), False])
        if int(candidate["timestamp"], 16) < target:
            lower = middle
        else:
            upper = middle
    return rpc("eth_getBlockByNumber", [hex(lower), False])


def collect(snapshot, before=None):
    directory = snapshot / "chain"
    directory.mkdir(exist_ok=True)
    require(not any(directory.iterdir()), "Refusing to overwrite an existing capture")
    started = datetime.now(timezone.utc).isoformat()
    market_bytes = (snapshot / "markets.json").read_bytes()
    markets = json.loads(market_bytes)["markets"]
    require(len(markets) == 37, "Market roster changed")
    collateral_set = {market["collateral_address"].lower() for market in markets}
    require(len(collateral_set) == 1, "Expected one collateral asset")
    collateral = collateral_set.pop()
    outcomes = {
        asset.lower(): {"market_id": market["id"].lower(), "outcome": label}
        for market in markets
        for asset, label in zip(market["outcome_addresses"], market["outcomes"], strict=True)
    }
    require(len(outcomes) == 111, "Outcome roster changed")
    require(int(rpc("eth_chainId", []), 16) == 10, "Wrong chain")
    finalized = rpc("eth_getBlockByNumber", ["finalized", False])
    head = select_cutoff(finalized, before)
    prior_block, start = parallel_map(
        lambda number: rpc("eth_getBlockByNumber", [hex(number), False]),
        [START_BLOCK - 1, START_BLOCK],
    )
    require(int(prior_block["timestamp"], 16) < START_TIME <= int(start["timestamp"], 16),
            "Start block no longer brackets the specified date")
    codes = parallel_map(lambda asset: rpc("eth_getCode", [asset, start["number"]]), outcomes)
    require(all(code == "0x" for code in codes), "An outcome existed before the capture interval")
    print("Confirmed chain, finalized cutoff, and pre-creation start", flush=True)
    assets = sorted([collateral, *outcomes])
    # Filtering the factory stream locally avoids the RPC's combinatorial topic limit.
    factory_events = []
    pools = {}
    for event in read_events({"address": FACTORY, "topics": [CREATED]}, int(head["number"], 16)):
        asset0, asset1 = ["0x" + topic[-40:] for topic in event["topics"][1:3]]
        if collateral not in (asset0, asset1):
            continue
        outcome = asset1 if asset0 == collateral else asset0
        if outcome not in outcomes:
            continue
        factory_events.append(event)
        fields = words(event["data"])
        pool_address = "0x" + f"{fields[1]:040x}"
        require(pool_address not in pools, "Duplicate pool creation")
        pools[pool_address] = {
            **outcomes[outcome], "outcome_address": outcome,
            "asset0_address": asset0, "asset1_address": asset1,
            "collateral_index": int(asset1 == collateral),
            "fee": int(event["topics"][3], 16), "creation_event": event,
        }
    require(pools, "No matching pools")
    require({pool["market_id"] for pool in pools.values()} == {market["id"].lower() for market in markets},
            "Pool discovery missed a market")
    asset_decimals = dict(zip(assets, parallel_map(
        lambda asset: int(rpc("eth_call", [{"to": asset, "data": "0x313ce567"}, head["number"]]), 16),
        assets), strict=True))
    states = dict(zip(pools, parallel_map(
        lambda address: rpc("eth_call", [{"to": address, "data": "0x3850c7bd"}, head["number"]]),
        pools), strict=True))
    events = read_events({"address": list(pools), "topics": [list(TOPICS.values())]}, int(head["number"], 16))
    print(f"Captured {len(pools)} pools and {len(events)} pool events", flush=True)
    transaction_hashes = sorted({event["transactionHash"] for event in [*factory_events, *events]})
    receipts = parallel_map(lambda tx_hash: rpc("eth_getTransactionReceipt", [tx_hash]), transaction_hashes)
    transactions = {}
    expected_by_transaction = defaultdict(list)
    for event in events:
        expected_by_transaction[event["transactionHash"]].append(event)
    for receipt in receipts:
        require(int(receipt["status"], 16) == 1, "Failed transaction")
        matching = [event for event in receipt["logs"]
                    if event["address"].lower() in pools and event["topics"][0] in TOPICS.values()]
        expected = expected_by_transaction[receipt["transactionHash"]]
        # Some RPC methods add blockTimestamp; compare the consensus event fields.
        fields = ["address", "topics", "data", "blockHash", "blockNumber", "transactionHash", "logIndex"]
        selected = lambda rows: [{key: row[key] for key in fields} for row in sorted(rows, key=event_key)]
        require(selected(matching) == selected(expected), "Receipt and interval event query disagree")
        transactions[receipt["transactionHash"]] = {
            key: receipt[key] for key in ["transactionHash", "from", "to", "blockHash", "blockNumber", "transactionIndex", "status"]
        }
    numbers = sorted({int(event["blockNumber"], 16) for event in [*factory_events, *events]})
    blocks = parallel_map(lambda number: rpc("eth_getBlockByNumber", [hex(number), False]), numbers)
    headers = {block["number"]: {key: block[key] for key in ["number", "hash", "timestamp"]} for block in blocks}
    require(rpc("eth_getBlockByNumber", [head["number"], False])["hash"] == head["hash"], "Cutoff block changed")
    evidence = {
        "rpc_url": RPC_URL, "chain_id": 10, "started_at_utc": started,
        "finished_at_utc": datetime.now(timezone.utc).isoformat(),
        "start_block": {key: start[key] for key in ["number", "hash", "timestamp"]},
        "prior_block": {key: prior_block[key] for key in ["number", "hash", "timestamp"]},
        "finalized_block": {key: head[key] for key in ["number", "hash", "timestamp"]},
        "latest_finalized_at_capture": {key: finalized[key] for key in ["number", "hash", "timestamp"]},
        "requested_before": before,
        "outcome_code_at_start": dict(zip(outcomes, codes, strict=True)),
        "collateral_address": collateral, "asset_decimals": asset_decimals,
        "pools": pools, "pool_states": states, "factory_events": factory_events,
        "events": events, "transactions": transactions, "blocks": headers,
    }
    write_json(directory / "evidence.json", evidence)
    result = analyze(evidence)
    write_json(directory / "audit.json", result)
    write_json(directory / "manifest.json", {
        "market_snapshot_sha256": hashlib.sha256(market_bytes).hexdigest(),
        "sha256": {name: hashlib.sha256((directory / name).read_bytes()).hexdigest()
                   for name in ["evidence.json", "audit.json"]},
        "scope": "Every Uniswap v3 factory pool pairing a roster outcome with its collateral; other venues excluded.",
        "receipt_check": "Every captured pool event matched the corresponding transaction receipt.",
    })
    return result


def analyze(evidence):
    pool_events = defaultdict(list)
    names = {topic: name for name, topic in TOPICS.items()}
    for event in evidence["events"]:
        require(not event["removed"], "Removed event")
        require(event["blockHash"] == evidence["blocks"][event["blockNumber"]]["hash"], "Block hash mismatch")
        require(event["blockHash"] == evidence["transactions"][event["transactionHash"]]["blockHash"], "Receipt block mismatch")
        pool_events[event["address"].lower()].append(event)
    collateral_decimals = evidence["asset_decimals"][evidence["collateral_address"]]
    origins = defaultdict(lambda: {"swap_events": 0, "transactions": set(), "markets": set(), "turnover": 0})
    liquidity_origins = set()
    rows = []
    swap_times = []
    for address, pool in evidence["pools"].items():
        events = sorted(pool_events[address], key=event_key)
        counts = Counter(names[event["topics"][0]] for event in events)
        require(counts["initialize"] == 1, "Expected exactly one initialization per pool")
        turnover = 0
        last_price = None
        first_swap = last_swap = None
        for event in events:
            name = names[event["topics"][0]]
            fields = words(event["data"])
            origin = evidence["transactions"][event["transactionHash"]]["from"].lower()
            time = timestamp(evidence["blocks"][event["blockNumber"]])
            if name in ("mint", "burn"):
                liquidity_origins.add(origin)
            if name == "initialize":
                last_price = fields[0]
            if name == "swap":
                last_price = fields[2]
                amount = abs(signed(fields[pool["collateral_index"]]))
                turnover += amount
                origins[origin]["turnover"] += amount
                origins[origin]["swap_events"] += 1
                origins[origin]["transactions"].add(event["transactionHash"])
                origins[origin]["markets"].add(pool["market_id"])
                swap_times.append(time)
                if first_swap is None:
                    first_swap = time
                last_swap = time
        state = words(evidence["pool_states"][address])
        require(last_price == state[0], "Final pool price differs from the captured event history")
        with localcontext() as context:
            context.prec = 60
            ratio = Decimal(state[0]) ** 2 / Decimal(2) ** 192
            price = ratio if pool["collateral_index"] == 1 else 1 / ratio
            price *= Decimal(10) ** (evidence["asset_decimals"][pool["outcome_address"]] - collateral_decimals)
        rows.append({
            "pool": address, "market_id": pool["market_id"], "outcome": pool["outcome"],
            "fee": pool["fee"], "counts": dict(counts),
            "turnover_susds": str(Decimal(turnover) / 10 ** collateral_decimals),
            "first_swap_utc": first_swap, "last_swap_utc": last_swap,
            "price_susds_at_cutoff": str(price),
        })
    origin_rows = [{
        "address": address, "swap_events": item["swap_events"],
        "transaction_count": len(item["transactions"]), "market_count": len(item["markets"]),
        "also_originated_liquidity_event": address in liquidity_origins,
        "turnover_susds": str(Decimal(item["turnover"]) / 10 ** collateral_decimals),
    } for address, item in sorted(origins.items(), key=lambda item: -item[1]["turnover"])]
    return {
        "summary": {
            "cutoff_block": int(evidence["finalized_block"]["number"], 16),
            "cutoff_utc": timestamp(evidence["finalized_block"]),
            "pool_count": len(rows), "market_count": len({row["market_id"] for row in rows}),
            "swap_event_count": sum(item["swap_events"] for item in origins.values()),
            "swap_transaction_count": len({tx for item in origins.values() for tx in item["transactions"]}),
            "transaction_origin_count": len(origins), "liquidity_origin_count": len(liquidity_origins),
            "turnover_susds": str(sum((Decimal(row["turnover_susds"]) for row in rows), Decimal(0))),
            "first_swap_utc": min(swap_times) if swap_times else None,
            "last_swap_utc": max(swap_times) if swap_times else None,
        },
        "origins": origin_rows, "liquidity_origins": sorted(liquidity_origins), "pools": rows,
    }


def verify(snapshot):
    directory = snapshot / "chain"
    manifest = json.loads((directory / "manifest.json").read_text())
    require(hashlib.sha256((snapshot / "markets.json").read_bytes()).hexdigest() == manifest["market_snapshot_sha256"],
            "Market snapshot changed")
    for name, expected in manifest["sha256"].items():
        require(hashlib.sha256((directory / name).read_bytes()).hexdigest() == expected, f"Checksum mismatch: {name}")
    evidence = json.loads((directory / "evidence.json").read_text())
    result = analyze(evidence)
    require(result == json.loads((directory / "audit.json").read_text()), "Audit is not reproducible")
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=["capture", "verify"])
    parser.add_argument("snapshot", type=Path)
    parser.add_argument("--before", help="Use the last block strictly before this timezone-qualified ISO time")
    args = parser.parse_args()
    require(args.mode == "capture" or args.before is None, "--before applies only to capture")
    result = collect(args.snapshot, args.before) if args.mode == "capture" else verify(args.snapshot)
    print(json.dumps({"summary": result["summary"], "origins": result["origins"]}, indent=2))
