#!/usr/bin/env python3
"""Read-only cutoff and settlement audit. Verify saved evidence without network access."""

import argparse
import hashlib
import importlib.util
import json
import math
import re
from datetime import datetime, timezone
from decimal import Decimal
from html.parser import HTMLParser
from pathlib import Path
from urllib.request import urlopen

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location(
    "chain", HERE.parents[1] / "2026-09-11/zcash-chain-audit.py")
chain = importlib.util.module_from_spec(spec)
spec.loader.exec_module(chain)


def read(path):
    return json.loads(path.read_text())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def header(block):
    return {key: block[key] for key in ("number", "hash", "timestamp")}


def source_snapshot(name, data):
    if name not in ("official-results.json", "launch.json"):
        return data
    post = json.loads(data)["post_stream"]["posts"][0]
    result = {"post": {key: post[key] for key in
                      ("id", "post_number", "created_at", "updated_at", "version")}}
    if name == "official-results.json":
        published = PublishedOutcomes()
        published.feed(post["cooked"])
        chain.require(len(published.outcomes) == 37, "Official result extraction is incomplete")
        result["published_outcomes_by_submission_id"] = published.outcomes
    # Retain the needed factual records and response hashes, not the discussion text.
    return (json.dumps(result, indent=2) + "\n").encode()


def capture(directory):
    config = read(HERE / "config.json")
    directory.mkdir(parents=True, exist_ok=False)
    old = read(HERE.parents[1] / "2026-09-11/zcash-pilot-data/chain/evidence.json")

    def fetch(item):
        name, url = item
        started = datetime.now(timezone.utc).isoformat()
        with urlopen(url, timeout=45) as response:
            data = response.read()
        (directory / name).write_bytes(source_snapshot(name, data))
        return {"file": name, "url": url, "started_at": started,
                "source_response_sha256": hashlib.sha256(data).hexdigest(),
                "finished_at": datetime.now(timezone.utc).isoformat()}

    sources = chain.parallel_map(fetch, config["sources"].items())
    chain.require(int(chain.rpc("eth_chainId", []), 16) == 10, "Wrong chain")
    head = chain.rpc("eth_getBlockByNumber", ["finalized", False])
    cutoff = chain.select_cutoff(head, config["cutoff"])
    following = chain.rpc("eth_getBlockByNumber", [hex(int(cutoff["number"], 16) + 1), False])
    pools = old["pools"]
    print("Reading swaps after the announced cutoff", flush=True)
    events = chain.read_events(
        {"address": list(pools), "topics": [chain.TOPICS["swap"]]},
        int(head["number"], 16), int(following["number"], 16))
    event_headers = chain.parallel_map(
        lambda number: header(chain.rpc("eth_getBlockByNumber", [number, False])),
        sorted({event["blockNumber"] for event in events}))
    print(f"Captured {len(events)} subsequent swaps; reading settlements", flush=True)
    market_ids = sorted({pool["market_id"] for pool in pools.values()})
    selectors = config["selectors"]

    def call(address, data):
        return chain.rpc("eth_call", [{"to": address, "data": data}, head["number"]])

    conditions = dict(zip(market_ids, chain.parallel_map(
        lambda market: call(market, selectors["conditionId()"]), market_ids), strict=True))
    requests = [(market, index) for market in market_ids for index in range(4)]

    def payout(request):
        market, index = request
        suffix = conditions[market][2:]
        if index == 3:
            data = selectors["payoutDenominator(bytes32)"] + suffix
        else:
            data = selectors["payoutNumerators(bytes32,uint256)"] + suffix + f"{index:064x}"
        return call(config["conditional_contract_address"], data)

    payout_words = chain.parallel_map(payout, requests)
    payouts = {market: payout_words[index * 4:(index + 1) * 4]
               for index, market in enumerate(market_ids)}
    states = dict(zip(pools, chain.parallel_map(
        lambda address: call(address, "0x3850c7bd"), pools), strict=True))
    chain.require(chain.rpc("eth_getBlockByNumber", [head["number"], False])["hash"] == head["hash"],
                  "Finalized block changed")
    chain.write_json(directory / "extension.json", {
        "rpc_url": chain.RPC_URL, "chain_id": 10, "requested_before": config["cutoff"],
        "cutoff": header(cutoff), "following": header(following), "as_of": header(head),
        "pools": pools, "events": events,
        "blocks": {block["number"]: block for block in event_headers},
        "conditional_contract_address": config["conditional_contract_address"], "conditions": conditions,
        "payout_words": payouts, "pool_states": states,
    })
    chain.write_json(directory / "manifest.json", {
        "sources": sources, "config_sha256": digest(HERE / "config.json"),
        "helper_sha256": digest(Path(chain.__file__)),
        "sha256": {path.name: digest(path) for path in sorted(directory.iterdir()) if path.is_file()},
    })


class PublishedOutcomes(HTMLParser):
    """Join official result sections to stable GitHub submission IDs."""

    def __init__(self):
        super().__init__()
        self.heading = False
        self.heading_text = ""
        self.section = None
        self.outcomes = {}

    def handle_starttag(self, tag, attrs):
        if tag in ("h1", "h2", "h3", "h4", "strong"):
            self.heading = True
            self.heading_text = ""
        if tag == "a":
            href = dict(attrs).get("href", "")
            match = re.fullmatch(
                r"https://github.com/Financial-Privacy-Foundation/ZcashCoinholderGrantsProgram/issues/(\d+)", href)
            if match:
                chain.require(self.section is not None, "Unclassified official result")
                chain.require(match[1] not in self.outcomes, "Duplicate official result")
                self.outcomes[match[1]] = self.section

    def handle_data(self, text):
        if self.heading:
            self.heading_text += text

    def handle_endtag(self, tag):
        if tag in ("h1", "h2", "h3", "h4", "strong"):
            title = self.heading_text.strip()
            if title == "Funded":
                self.section = 1
            elif title.startswith("Rejected"):
                self.section = 0
            elif title == "Abstain":
                self.section = None
            self.heading = False


def scores(probabilities, outcomes):
    chain.require(len(probabilities) == len(outcomes) > 0, "Score coverage mismatch")
    chain.require(all(0 < price < 1 for price in probabilities), "Price not interior; no clipping allowed")
    return {
        "mean_brier": sum((price - result) ** 2 for price, result in zip(probabilities, outcomes)) / len(outcomes),
        "mean_log_loss": -sum(math.log(price if result else 1 - price)
                              for price, result in zip(probabilities, outcomes)) / len(outcomes),
    }


def analyze(directory, snapshot):
    for name, expected in read(directory / "manifest.json")["sha256"].items():
        chain.require(digest(directory / name) == expected, f"Changed evidence: {name}")
    earlier = chain.verify(snapshot)
    original = read(snapshot / "chain/evidence.json")
    extra = read(directory / "extension.json")
    boundary = int(datetime.fromisoformat(extra["requested_before"]).timestamp())
    chain.require(int(extra["cutoff"]["timestamp"], 16) < boundary <=
                  int(extra["following"]["timestamp"], 16), "Cutoff does not bracket the deadline")
    chain.require(int(extra["following"]["number"], 16) == int(extra["cutoff"]["number"], 16) + 1,
                  "Cutoff blocks are not adjacent")
    chain.require(extra["cutoff"] == original["finalized_block"], "Pre-poll cutoff differs")
    chain.require(extra["pools"] == original["pools"], "Pool roster changed")
    chain.require((directory / "vote-summary.json").read_bytes() ==
                  (directory / "vote-summary-valar.json").read_bytes(), "Vote mirrors differ")
    results = read(directory / "results.json")
    chain.require(digest(directory / "vote-summary.json") == results["chain"]["sha256"],
                  "OpenZcash references different vote data")
    official = read(directory / "official-results.json")["published_outcomes_by_submission_id"]
    roster = re.findall(r'id: (\d+),\s+address: "(0x[a-f0-9]{40})",\s+title: "([^"]+)"',
                        (directory / "market-roster.ts").read_text())
    by_ballot = {int(number): (market, title) for number, market, title in roster}
    votes = {row["id"]: row for row in read(directory / "vote-summary.json")["proposals"]}
    chain.require(len(roster) == len(by_ballot) == len(votes) == len(official) == 37,
                  "Incomplete or ambiguous outcome join")
    prices = {(pool["market_id"], pool["outcome"]): pool for pool in earlier["pools"]}
    current = {quote["id"].lower(): quote for quote in read(snapshot / "markets.json")["marketsData"].values()}
    rows = []
    for result in results["rows"]:
        market, title = by_ballot[result["ballot"]]
        vote = votes[result["ballot"]]
        values = {option["label"]: Decimal(option["total_value"]) / 8
                  if "total_value" in option else Decimal(0) for option in vote["options"]}
        # Protobuf omits total_value exactly for zero; all four labelled options must exist.
        expected_labels = ["Accept", "Reject - Do Not Support the Proposed Project",
                           "Reject - Would Reconsider in a Future Round at a Lower Amount", "Abstain"]
        chain.require(set(values) == set(expected_labels), "Missing vote option")
        for field, label in zip(("accept", "reject", "lower", "abstain"), expected_labels):
            chain.require(values[label] == Decimal(str(result[field])), "Vote transcription mismatch")
        outcome = int(sum(values.values()) >= 420000 and values["Accept"] >
                      values[expected_labels[1]] + values[expected_labels[2]])
        chain.require(official[result["id"]] == outcome, "Official result disagrees with tally")
        payouts = [int(word, 16) for word in extra["payout_words"][market]]
        chain.require(payouts[3] == sum(payouts[:3]) > 0, "Unresolved or malformed settlement")
        chain.require(payouts == ([1, 0, 0, 1] if outcome else [0, 1, 0, 1]),
                      f"Settlement differs from official result: {market}")
        rows.append({
            "ballot": result["ballot"], "submission_id": result["id"], "market_id": market,
            "market_title": title, "official_title": result["title"], "vote_title": vote["title"],
            "approved": outcome, "payout_numerators": payouts[:3],
            "pre_poll_yes": float(prices[market, "Yes"]["price_susds_at_cutoff"]),
            "pre_poll_no": float(prices[market, "No"]["price_susds_at_cutoff"]),
            "current_website_yes": current[market]["yesPrice"],
            "original_gpt_forecast": None,
        })
    chain.require(len(rows) == len({row["market_id"] for row in rows}) == 37, "Duplicate market join")
    turnover = Decimal(0)
    last_price = {pool: chain.words(state)[0] for pool, state in original["pool_states"].items()}
    chain.require(len(extra["events"]) == len({chain.event_key(event) for event in extra["events"]}),
                  "Duplicate post-cutoff event")
    for event in sorted(extra["events"], key=chain.event_key):
        block = extra["blocks"][event["blockNumber"]]
        chain.require(not event["removed"] and block["hash"] == event["blockHash"], "Invalid event block")
        chain.require(boundary <= int(block["timestamp"], 16) <= int(extra["as_of"]["timestamp"], 16),
                      "Event outside post-cutoff interval")
        pool = extra["pools"][event["address"]]
        fields = chain.words(event["data"])
        turnover += Decimal(abs(chain.signed(fields[pool["collateral_index"]]))) / 10 ** 18
        last_price[event["address"]] = fields[2]
    chain.require(original["asset_decimals"][original["collateral_address"]] == 18, "Collateral decimals changed")
    chain.require(all(last_price[pool] == chain.words(state)[0] for pool, state in extra["pool_states"].items()),
                  "Post-cutoff event replay differs from current contract prices")
    outcomes = [row["approved"] for row in rows]
    return {
        "summary": {
            "market_count": len(rows), "approved": sum(outcomes), "settlements_matching": len(rows),
            "cutoff_utc": chain.timestamp(extra["cutoff"]), "cutoff_block": int(extra["cutoff"]["number"], 16),
            "as_of_utc": chain.timestamp(extra["as_of"]),
            "pre_poll": earlier["summary"],
            "post_cutoff_swaps": len(extra["events"]),
            "post_cutoff_transactions": len({event["transactionHash"] for event in extra["events"]}),
            "post_cutoff_markets": len({extra["pools"][event["address"]]["market_id"] for event in extra["events"]}),
            "post_cutoff_turnover_susds": str(turnover),
            "first_post_cutoff_swap_utc": chain.timestamp(extra["blocks"][extra["events"][0]["blockNumber"]]) if extra["events"] else None,
            "last_swap_utc": chain.timestamp(extra["blocks"][extra["events"][-1]["blockNumber"]]) if extra["events"] else None,
            "pre_poll_yes_quote_scores": scores([row["pre_poll_yes"] for row in rows], outcomes),
            "current_website_yes_quote_scores": scores([row["current_website_yes"] for row in rows], outcomes),
            "gpt_comparison": None,
        }, "markets": rows,
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("capture", "verify"))
    parser.add_argument("directory", type=Path)
    parser.add_argument("--snapshot", type=Path)
    args = parser.parse_args()
    if args.mode == "capture":
        capture(args.directory)
    else:
        chain.require(args.snapshot is not None, "--snapshot is required for verification")
        result = analyze(args.directory, args.snapshot)
        report = args.directory.parent / "audit.json"
        if report.exists():
            chain.require(read(report) == result, "Saved report is not reproducible")
        else:
            chain.write_json(report, result)
        print(json.dumps(result["summary"], indent=2))
