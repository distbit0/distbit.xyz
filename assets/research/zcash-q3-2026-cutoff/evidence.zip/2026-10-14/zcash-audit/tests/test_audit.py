"""Cross-source checks against the complete real captures, without network access."""

import importlib.util
import unittest
from decimal import Decimal, localcontext
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("audit", BASE / "audit.py")
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)


class CapturedRoundAudit(unittest.TestCase):
    def test_full_round_reconciles_votes_official_results_and_settlements(self):
        result = audit.analyze(BASE / "evidence", BASE / "snapshot")
        self.assertEqual(result, audit.read(BASE / "audit.json"))
        self.assertEqual(result["summary"]["settlements_matching"], 37)
        self.assertEqual(result["summary"]["approved"], 17)
        self.assertTrue(all(row["original_gpt_forecast"] is None for row in result["markets"]))
        self.assertIsNone(result["summary"]["gpt_comparison"])
        # The corrected official result must survive the raw-tally and payout joins.
        connaugh = next(row for row in result["markets"] if row["submission_id"] == "55")
        tally = next(row for row in audit.read(BASE / "evidence/results.json")["rows"] if row["id"] == "55")
        self.assertGreater(tally["abstain"], tally["accept"])
        self.assertEqual(connaugh["payout_numerators"], [1, 0, 0])

    def test_pre_and_post_cutoff_turnover_reconcile_to_the_independent_website_capture(self):
        summary = audit.read(BASE / "audit.json")["summary"]
        actual = Decimal(summary["pre_poll"]["turnover_susds"]) + Decimal(summary["post_cutoff_turnover_susds"])
        reported = sum((Decimal(chart["totalVolumeMarket"].split(" ")[0])
                        for chart in audit.read(BASE / "snapshot/charts.json").values()), Decimal(0))
        # The website accumulates swaps using binary floating point.
        self.assertLess(abs(actual - reported), Decimal("0.00000000001"))
        self.assertGreater(Decimal(summary["post_cutoff_turnover_susds"]), 0)

    def test_current_website_quotes_match_all_74_pool_contract_states(self):
        evidence = audit.read(BASE / "evidence/extension.json")
        quotes = {row["id"].lower(): row for row in audit.read(BASE / "snapshot/markets.json")["marketsData"].values()}
        self.assertEqual(len(evidence["pools"]), 74)
        for address, pool in evidence["pools"].items():
            state = audit.chain.words(evidence["pool_states"][address])
            with localcontext() as context:
                context.prec = 60
                ratio = Decimal(state[0]) ** 2 / Decimal(2) ** 192
                price = ratio if pool["collateral_index"] == 1 else 1 / ratio
            field = "yesPrice" if pool["outcome"] == "Yes" else "noPrice"
            reported = Decimal(str(quotes[pool["market_id"]][field]))
            self.assertLess(max(price / reported, reported / price), Decimal("1.0001"))


if __name__ == "__main__":
    unittest.main()
